	
	<!-- jQuery -->
    <script src="<?php echo base_url()?>assets/bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url()?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url()?>assets/bower_components/metisMenu/dist/metisMenu.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-1.7.2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.colorbox-min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url()?>assets/dist/js/sb-admin-2.js"></script>

    <div class="clearfix"></div>
    <footer>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Portal Rapat | &copy;by Kelompok 6 RPL - 2016</footer></div>

</body>

</html>